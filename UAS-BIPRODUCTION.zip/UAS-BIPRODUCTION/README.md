![SAMPUL MSN](https://user-images.githubusercontent.com/111676859/214242782-ba0ddd73-0545-4155-9ae1-0348d027ae8c.jpg)

# Mulia Sejati Nusantara Production 

# Tentang MSN PRODUCTION

PT. MULIA SEJATI NUSANTARA Berdiri Pada Tanggal 24 Juni 2019 Sebuah Perseroan Terbatas yang bergerak di bidang jasa Suplier & Contractor.Kemudian pada 22 January 2022 PT. MULIA SEJATI NUSANTARA Membuka cabang usaha Baru di Bidang Teknologi yang meliputi Pembuatan Website, Apilkasi Mobile, Branding, Content Creative, Digital Marketing & Advertising. Cabang ini di namakan “Mulia Sejati Nusantara Production" atau di singkat MSN Production.

1. Jasa Pembuatan Website dan Aplikasi Android & iOS: Sistem Informasi, Sistem Administrasi, Sistem Promosi & Wedding.
2. Jasa pemasaran produk atau jasa melalui saluran Periklanan Online: Mesin Pencarian Google, Jaringan Display Iklan Google, Youtube, Facebook, Instagram, Tiktok, Twitter
3. Jasa pembuatan Branding & Konten Kreatif.

# Visi & Misi MSN PRODUCTION

*Misi

Menjadi Perusahaan swasta yang handal dalam penyedia jasa dan perdagangan sesuai dengan KBLI yang dimiliki.

*Layanan

Dapatkan loyalitas konsumen, berikan mereka pengalaman yang berkesan dengan menciptakan hubungan yang saling menguntungkan.

*Visi

Dalam melaksanakan tugas - tugasnya Mulia Sejati Nusantara Production senantiasa menjaga, profesionalisme, kejujuran, kebersamaan, ketertiban, dan kesehatan kerja sehingga dihasilkan suatu karya yang berkualitas
